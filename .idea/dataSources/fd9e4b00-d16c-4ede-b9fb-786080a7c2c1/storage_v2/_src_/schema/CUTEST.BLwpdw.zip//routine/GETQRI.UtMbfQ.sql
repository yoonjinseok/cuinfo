create FUNCTION        getQri (v_url IN varchar2) 
RETURN varchar2 IS url varchar(500);
BEGIN
   
    IF(instr(v_url,'?',1) > 0) THEN
        BEGIN
       SELECT
          substr(v_url,instr(v_url,'?',1)+1) INTO url
       FROM dual;
       END;
    ELSE
        BEGIN
        SELECT
          '' INTO url
       FROM dual;
       END;
    END IF;
    
   
   RETURN url;
   
   EXCEPTION
     WHEN NO_DATA_FOUND THEN
       NULL;
     WHEN OTHERS THEN
       -- Consider logging the error and then re-raise
       RAISE;
END getQri;
/

