create FUNCTION        getSp (v_url IN varchar2) 
RETURN varchar2 IS url varchar(100);
BEGIN
   
   SELECT
      substr(v_url,instr(v_url,'.',1,1)+1,(instr(v_url,'.',1,2) - instr(v_url,'.',1,1)) - 1) INTO url
   FROM dual;
   
   RETURN url;
   
   EXCEPTION
     WHEN NO_DATA_FOUND THEN
       NULL;
     WHEN OTHERS THEN
       -- Consider logging the error and then re-raise
       RAISE;
END getSp;
/

